#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from PyQt4 import QtGui, QtWebKit
from PyQt4.QtGui import QIcon
from PyQt4.QtWebKit import QWebSettings

import xamai.Constants as const
from xamai.Listener import ListenerWebKit

class Browser(QtGui.QMainWindow):

    def __init__(self, html="", tpl={}):
        QtGui.QMainWindow.__init__(self)
        self.setWindowIcon(QIcon(const.LOCATION+"/img/DB_Protector_16X16-01.png"))
        self.setWindowTitle("DB Protector")
        self.setFixedSize(800, 600)
        self.centralwidget = QtGui.QWidget(self)

        self.mainLayout = QtGui.QHBoxLayout(self.centralwidget)
        self.mainLayout.setSpacing(0)
        self.mainLayout.setMargin(1)

        self.frame = QtGui.QFrame(self.centralwidget)

        self.gridLayout = QtGui.QVBoxLayout(self.frame)
        self.gridLayout.setMargin(0)
        self.gridLayout.setSpacing(0)

        self.horizontalLayout = QtGui.QHBoxLayout()
        self.gridLayout.addLayout(self.horizontalLayout)

        self.html = QtWebKit.QWebView()
        self.gridLayout.addWidget(self.html)
        self.mainLayout.addWidget(self.frame)
        self.setCentralWidget(self.centralwidget)
        self.html.settings().setDefaultTextEncoding("UTF-8")
        self.html.settings().setAttribute(QWebSettings.PluginsEnabled, True)
        self.html.settings().setAttribute(QWebSettings.JavascriptEnabled, True)

        if html:
            self.browse(html, tpl)

    def browse(self,  html, tpl):
        fd = open(html, "r")
        tmp_page = fd.read().decode("utf-8")
        fd.close()

        for key, value in tpl.items():
            tmp_page = tmp_page.replace("{%s}" % key, str(value))

        listener = ListenerWebKit()

        self.html.page().mainFrame().addToJavaScriptWindowObject("listener", listener)
        self.html.setHtml(tmp_page)
        self.html.show()

data = {
    "css": "",
    "alert": ""
}

HTML = const.LOCATION + "/gui/login.html"
app = QtGui.QApplication(sys.argv)
win = Browser(HTML, data)
win.show()
sys.exit(app.exec_())