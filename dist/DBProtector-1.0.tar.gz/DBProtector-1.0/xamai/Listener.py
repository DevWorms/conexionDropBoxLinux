#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from PyQt4 import QtCore, QtGui

class ListenerWebKit(QtCore.QObject):
    """Simple class with one slot and one read-only property."""

    @QtCore.pyqtSlot(str)
    def showMessage(self, msg):
        print msg

    def _pyVersion(self):
        """Return the Python version."""
        return sys.version

    def alertMsg(self):
        return "hola"