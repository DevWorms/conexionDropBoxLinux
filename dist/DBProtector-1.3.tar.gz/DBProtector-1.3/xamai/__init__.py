#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-

# Nothing here :)